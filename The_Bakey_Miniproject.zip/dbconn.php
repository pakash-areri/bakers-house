
<?php
$host="localhost";
$user="root";
$password="";

$db="the_bakers_house";


$conn=mysqli_connect($host,$user,$password);
mysqli_select_db($conn,$db);


?>